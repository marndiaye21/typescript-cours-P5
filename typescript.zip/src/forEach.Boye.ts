const eleves = ["sow", "niass", "moustapha"];
eleves.forEach(function (_,index) {
  // [index] = eleves + "s";
  console.log(index)
});
console.log(eleves);

