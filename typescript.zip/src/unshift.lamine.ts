const tableau = [1,2,3]
tableau.unshift(15,13)
console.log(tableau)