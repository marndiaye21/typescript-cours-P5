const elements = [1, 12, 5, 23, "salut", "salut", NaN];
console.log(elements.indexOf(NaN))

// const str = "bonjour";
// console.log(str.indexOf("j"));
