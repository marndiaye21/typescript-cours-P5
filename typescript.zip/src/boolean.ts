// function estPaire(nombre:number):boolean{
//     return nombre%2===0 ;
// }
// const resul:boolean = estPaire(2);
// console.log(resul);
let ok:boolean= true;

// if (ok) {
//     console.log("ok");
// }else{
//     console.log("ko")
// }
const object1 = Boolean("SONKO");
// if (object1) {
//     console.log("ok");
// }else{
//     console.log("ko")
// }

let object2:Boolean = true;
console.log(typeof object2);

if (object2) {
    console.log(object2);
}else{
    console.log("ko")
}
