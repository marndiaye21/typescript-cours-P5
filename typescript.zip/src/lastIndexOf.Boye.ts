const number=[1,2,3,4,5]
const lastIndex=number.lastIndexOf(2)
console.log(lastIndex);