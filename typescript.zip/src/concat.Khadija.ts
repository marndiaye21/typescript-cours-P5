const num1=["1",2,3]
const num2=["maman"]
const num3=["maman"]
const lesdeux=num1.concat(num2,num3)
console.log(lesdeux);
