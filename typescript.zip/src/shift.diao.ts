const tabs=[1,"2",3];
const first = tabs.shift();
console.log(typeof (first));
// let e :undefined|number|string;
// while ((e = tabs.shift()) !== undefined) {
//   console.log(e);
  
// }
