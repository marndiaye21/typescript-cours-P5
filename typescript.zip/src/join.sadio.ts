const array=[1, "tout", "le", "monde"]
  let separateur=" "
   let phrase=array.join()
   console.log(phrase);
   