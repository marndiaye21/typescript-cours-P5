// let variable: object = {
//     name: "Moustapha",
//     age: 27
// };

// if ("name" in variable && "age" in variable) {
//     console.log(variable.name, variable.age);
// }

// let fun : object = function () {
//     console.log("Bonjour");
// }

// if (fun instanceof Function) {
//     fun();
// }

let obj: object = new Number(1);
