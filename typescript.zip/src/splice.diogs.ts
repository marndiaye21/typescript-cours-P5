const t = ["diogal","moussa","mendy","wane"];
const a =t.splice(8,8);
console.log(t);
console.log(a);


