const nombres = [1,2,3]
const suppr = nombres.pop();
console.log(suppr);
console.log(nombres);
// const obj = [
//   {
//     nom:"sira",
//     age:2
//   },
//   {
//     nom:"breukh",
//     age:5
//   }
// ]
// const supp = obj.pop()
// console.log(supp);
// console.log(obj);
