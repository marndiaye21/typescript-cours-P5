//les numbers 
let exemple1: number = 12;
let exemple2: number = 13.5;
let exemple3:number= 0b1010;
let exemple3_3: number = parseInt("1010", 2);
let exemple4:number = 0xFF;
let exemple4_4: number = parseInt("FF", 16);
let exemple5: number = 0o77;
let exemple7: number= 12;

console.log(exemple1);
console.log(exemple2);
console.log(exemple3);
console.log(exemple4);
console.log(exemple5);
console.log(exemple3_3);
console.log(exemple4_4);




